# Tshirt store for pro backend developer course

Please add env variables for the project

---

### PORT=4000

### DB_URL=

### JWT_SECRET=

### JWT_EXPIRY=

### COOKIE_TIME=

### CLOUDINARY_NAME=

### CLOUDINARY_API_KEY=

### CLOUDINARY_API_SECRET=

### SMTP_HOST=

### SMTP_PORT=

### SMTP_USER=

### SMTP_PASS=

### STRIPE_API_KEY=

### STRIPE_SECRET=

### RAZORPAY_API_KEY=

### RAZORPAY_SECRET=

---

[LearnCodeOnline](https://courses.learncodeonline.in/learn)
updat the variables before deploying
