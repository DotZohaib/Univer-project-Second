# welcome to pro backend developer course code files

## If you like this course, please drop a thanks node at my social profiles.

[CoderCommunity](https://web.codercommunity.io)

[Website](https://hiteshchoudahry.com)

[Instagram](https://instagram.com/hiteshchoudharyofficial)

of course there are bugs in these code files. As you teach you focus more on concept and less on production level execution. If you find any bug, consider that as your challenge to fix them.